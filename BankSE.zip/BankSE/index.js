function checkCondition(){
  
  var myTextBox = document.getElementById("userN");
  var username = myTextBox.value;
  if(username=== "customer"){
    window.location = 'home.html';
  }else{
    alert("wrong username");
  }
}
